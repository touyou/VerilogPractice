fadd.svがSystemVerilogでのfaddのコード、testディレクトリがvivadoのプロジェクトになっています。
シミュレーションは./test.shを動かすことでrunallがはしるようになっています。

LUTは695、CARRY4は33でした。

また最大周波数は1s/20.339ns Hzでした。
